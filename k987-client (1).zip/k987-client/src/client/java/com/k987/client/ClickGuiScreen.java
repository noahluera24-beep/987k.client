package com.k987.client;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ClickGuiScreen extends Screen {
    // ---- Red theme (ARGB) ----
    private static final int DIM        = 0x99000000;
    private static final int PANEL      = 0xF0120709;
    private static final int PANEL_EDGE = 0xFF3A0E14;
    private static final int SIDEBAR    = 0xF0170A0D;
    private static final int ACCENT     = 0xFFE0233A;
    private static final int ACCENT_BG  = 0x55E0233A;
    private static final int HOVER_BG   = 0x33E0233A;
    private static final int CARD       = 0xFF1B0C0F;
    private static final int TEXT       = 0xFFFFFFFF;
    private static final int TEXT_DIM   = 0xFF9A7A7E;

    private static final String[] MODULE_CATEGORIES = {"Combat", "Mace", "Misc", "Movement", "Spear", "Visual"};
    private static final String[] GENERAL = {"Settings", "Theme", "Configs", "Socials", "Keybinds"};

    // Every module count is 0 for now (nothing implemented yet)
    private static final int[] MODULE_COUNTS = {0, 0, 0, 0, 0, 0};

    private int selected = 0; // index into MODULE_CATEGORIES (0..5) then GENERAL (6..10)

    private static final int PW = 460, PH = 290, SIDE_W = 125;
    private int px, py;

    public ClickGuiScreen() {
        super(Text.literal("987k Client"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int total() {
        return MODULE_CATEGORIES.length + GENERAL.length;
    }

    private String nameOf(int i) {
        return i < MODULE_CATEGORIES.length ? MODULE_CATEGORIES[i] : GENERAL[i - MODULE_CATEGORIES.length];
    }

    /** y position of the sidebar item i */
    private int itemY(int i) {
        if (i < MODULE_CATEGORIES.length) return py + 62 + i * 26;
        return py + 62 + MODULE_CATEGORIES.length * 26 + 34 + (i - MODULE_CATEGORIES.length) * 26;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        px = (width - PW) / 2;
        py = (height - PH) / 2;

        ctx.fill(0, 0, width, height, DIM);

        // Panel
        ctx.fill(px - 1, py - 1, px + PW + 1, py + PH + 1, ACCENT);
        ctx.fill(px, py, px + PW, py + PH, PANEL);

        // Sidebar
        ctx.fill(px + 8, py + 8, px + SIDE_W, py + PH - 8, SIDEBAR);
        ctx.fill(px + 8, py + 8, px + SIDE_W, py + 9, PANEL_EDGE);

        // Logo
        ctx.drawText(textRenderer, "987k", px + 18, py + 18, ACCENT, true);
        int w = textRenderer.getWidth("987k ");
        ctx.drawText(textRenderer, "Client", px + 18 + w, py + 18, TEXT, true);
        ctx.drawText(textRenderer, "RELEASE 1.0.0", px + 18, py + 30, TEXT_DIM, false);

        ctx.drawText(textRenderer, "MODULES", px + 18, py + 50, TEXT_DIM, false);
        int generalLabelY = itemY(MODULE_CATEGORIES.length) - 12 + 0;
        ctx.drawText(textRenderer, "GENERAL", px + 18, generalLabelY, TEXT_DIM, false);

        // Sidebar items
        for (int i = 0; i < total(); i++) {
            int y = itemY(i);
            int x1 = px + 14, x2 = px + SIDE_W - 6;
            boolean hover = mouseX >= x1 && mouseX <= x2 && mouseY >= y && mouseY < y + 22;
            if (i == selected) {
                ctx.fill(x1, y, x2, y + 22, ACCENT_BG);
                ctx.fill(x1, y, x1 + 2, y + 22, ACCENT);
            } else if (hover) {
                ctx.fill(x1, y, x2, y + 22, HOVER_BG);
            }
            ctx.drawText(textRenderer, nameOf(i), x1 + 10, y + 7, i == selected ? TEXT : 0xFFD8C4C6, false);

            if (i < MODULE_CATEGORIES.length) {
                String c = String.valueOf(MODULE_COUNTS[i]);
                ctx.drawText(textRenderer, c, x2 - 6 - textRenderer.getWidth(c), y + 7, TEXT_DIM, false);
            }
        }

        // Header
        int cx = px + SIDE_W + 16;
        String name = nameOf(selected);
        boolean isModuleCat = selected < MODULE_CATEGORIES.length;
        int count = isModuleCat ? MODULE_COUNTS[selected] : 0;

        ctx.drawText(textRenderer, name, cx, py + 20, ACCENT, true);
        ctx.drawText(textRenderer, isModuleCat ? "Modules" : "", cx + textRenderer.getWidth(name + " "), py + 20, TEXT, true);
        if (isModuleCat) {
            ctx.drawText(textRenderer, count + " modules \u00b7 0 enabled", cx, py + 34, TEXT_DIM, false);
        }

        // Search box (visual only for now)
        int sx2 = px + PW - 14, sx1 = sx2 - 150;
        ctx.fill(sx1 - 1, py + 16, sx2 + 1, py + 37, PANEL_EDGE);
        ctx.fill(sx1, py + 17, sx2, py + 36, CARD);
        ctx.drawText(textRenderer, "Search modules", sx1 + 8, py + 23, TEXT_DIM, false);

        // Content area
        int ax1 = cx, ax2 = px + PW - 14, ay1 = py + 58, ay2 = py + PH - 14;
        ctx.fill(ax1, ay1, ax2, ay2, CARD);
        ctx.fill(ax1, ay1, ax2, ay1 + 1, PANEL_EDGE);

        String msg = isModuleCat ? "No modules yet" : name + " - coming soon";
        ctx.drawText(textRenderer, msg,
                (ax1 + ax2) / 2 - textRenderer.getWidth(msg) / 2,
                (ay1 + ay2) / 2 - 4, TEXT_DIM, false);

        // Footer hint
        String hint = "Right Shift to close";
        ctx.drawText(textRenderer, hint, ax2 - textRenderer.getWidth(hint) - 4, ay2 - 12, 0xFF5A3A3E, false);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            double mx = click.x(), my = click.y();
            for (int i = 0; i < total(); i++) {
                int y = itemY(i);
                if (mx >= px + 14 && mx <= px + SIDE_W - 6 && my >= y && my < y + 22) {
                    selected = i;
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }
}
