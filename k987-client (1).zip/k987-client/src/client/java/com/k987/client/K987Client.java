package com.k987.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class K987Client implements ClientModInitializer {
    private boolean wasDown = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient client) {
        if (client.getWindow() == null) return;
        long handle = client.getWindow().getHandle();
        boolean down = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;

        // Open only on a fresh press, and only when no other screen (chat, inventory...) is open
        if (down && !wasDown && client.currentScreen == null && client.world != null) {
            client.setScreen(new ClickGuiScreen());
        }
        wasDown = down;
    }
}
